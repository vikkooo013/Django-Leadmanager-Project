from django.db import models



class members(models.Model):
    id  = models.CharField(primary_key=True, max_length=100)
    real_name = models.CharField(max_length=100, unique=True)
    tz = models.CharField(max_length=100)

class activity_periods(models.Model):
    start_time=models.DateTimeField(blank=True)
    end_time=models.DateTimeField(blank=True)
    member = models.ForeignKey(members,default="",on_delete=models.CASCADE)








