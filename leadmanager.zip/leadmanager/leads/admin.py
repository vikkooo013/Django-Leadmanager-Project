from django.contrib import admin
from .models import members,activity_periods

# Register your models here.
admin.register(members)
admin.register(activity_periods)