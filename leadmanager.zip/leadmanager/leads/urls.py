from rest_framework import routers
from .views import membersViewSet


router = routers.DefaultRouter()
router.register('api/members', membersViewSet, 'members')

urlpatterns = router.urls
