from django.shortcuts import render

# Create your views here.
from leads.models import members, activity_periods
from rest_framework import viewsets, permissions
from .serializers import membersSerializer


class membersViewSet(viewsets.ModelViewSet):
    queryset = members.objects.all()

    serializer_class = membersSerializer


